
  # Página web arquitecto Zacatecas

  This is a code bundle for Página web arquitecto Zacatecas. The original project is available at https://www.figma.com/design/7FOSIxeoBEoJltJDDhTHcu/P%C3%A1gina-web-arquitecto-Zacatecas.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  